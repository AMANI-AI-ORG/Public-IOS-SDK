//
//  SpeechVerifierSDK.h
//  SpeechVerifierSDK
//
//  Created by Bedri Doğan on 21.09.2026.
//

#import <Foundation/Foundation.h>

//! Project version number for SpeechVerifierSDK.
FOUNDATION_EXPORT double SpeechVerifierSDKVersionNumber;

//! Project version string for SpeechVerifierSDK.
FOUNDATION_EXPORT const unsigned char SpeechVerifierSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SpeechVerifierSDK/PublicHeader.h>


